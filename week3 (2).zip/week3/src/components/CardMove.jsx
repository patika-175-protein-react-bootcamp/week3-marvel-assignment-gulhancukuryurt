import React, { useState, useEffect } from "react";
import Card from "./components/Card";
import axios from "axios";

const CardMove = ({ pages, setEnd }) => {
  const [hero, setHero] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    
    window.location.hash = pages;
    getData();
  }, [pages]);

  const getData = () => {
    
    const storageItems = JSON.parse(sessionStorage.getItem("info")) || {};
    const limit = JSON.parse(sessionStorage.getItem("limit")) || 0;
    setLoading(true);

    if (!storageItems[pages]) {axios
        .get(
          `https://gateway.marvel.com/v1/public/characters?ts=1&apikey=${
            process.env.REACT_APP_PUBLIC_KEY
          }&hash=${process.env.REACT_APP_ENCODED_KEY}&offset=${
            (page - 1) * 20
          }&limit=20`
        ) .then((resp) => {
          storageItems[pages] = [...resp.data.data.results];
          sessionStorage.setItem("info", JSON.stringify(storageItems));
          sessionStorage.setItem(
            "limit",
            JSON.stringify(resp.data.data.total / 20)
          );
          setEnd(resp.data.data.total / 20);
          setHero(resp.data.data.results);
          setLoading(false);
        });
    } else {
      setHero(storageItems[pages]);
      setEnd(limit);
      setLoading(false);
    }
  };

  return (
    <section className="card">
      {hero && <Card hero={hero} loading={loading} />}
    </section>
  );
};

export default CardMove;
