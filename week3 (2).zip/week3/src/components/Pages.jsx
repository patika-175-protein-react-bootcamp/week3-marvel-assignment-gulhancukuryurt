import React from "react";

const Pages= ({ page, setPage, limit }) => {
  return (
    <section class="pages">
      {page > 1 && (
        <>
          <span  onClick={() => setPage(page - 1)}>
            &larr;
          </span>
          <span className="pagination" onClick={() => setPage(1)}>
            1
          </span> </>
      )}

      {page > 3 && <span>...</span>}
      {page > 2 && (
        <span className="pagination" onClick={() => setPage(page - 1)}>
          {page - 1}
        </span>
      )}

      <span className="pagination">
        {page}
      </span>

      {page < limit && (
        <span className="pagination" onClick={() => setPage(page + 1)}>
          {page + 1}
        </span>
      )}

      {page < limit - 2 && <span>...</span>}

      {page < limit - 1 && (
        <>
          <span className="pagination" onClick={() => setPage(78)}>
            {limit}
          </span>
          <span className="pagination" onClick={() => setPage(page + 1)}>
            &rarr;
          </span>
        </>
      )}
    </section>
  );
};

export default Pages;
