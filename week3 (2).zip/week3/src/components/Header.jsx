import React from "react";
import BackgroundImage from "../../photos/image2.png";
import MarvelText from "../../photos/image1.png";

const Header = () => {
  return (
    <section class="header">
      <img
        src={BackgroundImage}/>

      <img src={MarvelText} alt="Text"  />
    </section>
  );
};

export default Header;
