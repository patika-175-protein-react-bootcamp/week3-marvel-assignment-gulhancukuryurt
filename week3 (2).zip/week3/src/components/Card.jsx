import React from "react";
import Gray from "../../photos/back.png";

const Card = ({ hero, load }) => {
  return (
    <>
      {hero.map((a) => (
        <div className="card" key={a.id}>
          <img
            src={
              !load
                ? a.thumbnail.path +
                  "/portrait_xlarge." +
                  a.thumbnail.extension
                : Gray}
            alt={a.name + "img"}
            className={"card"}
          />
          <p className={"cardt"}>
            {!load ? a.name : "Loading Page..."}
          </p>
        </div>
      ))}
    </>
  );
};

export default Card;
