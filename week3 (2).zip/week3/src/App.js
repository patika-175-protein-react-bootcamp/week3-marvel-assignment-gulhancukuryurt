import React, { useState, useEffect } from "react";
import "./App.css";
import CardMove from "./components/CardMove";
import Header from "./components/Header";
import Pages from "./components/Pages";

function App() {
  const [page, setPage] = useState(1); 
  const [limit, setLimit] = useState(0); 

  const pageChecker = () => {
    let pageToCheck = parseInt(window.location.hash.split("#")[1]);
    if (page !== pageToCheck) {
      setPage(pageToCheck);
    }
  };

  useEffect(() => {
    
    window.addEventListener("hashchange", () => pageChecker());
    return () => window.removeEventListener("hashchange", () => pageChecker());
  }, []);

  return (
    <body>
      <Header /> 
      <section className="content">
        <CardMove page={page} setLimit={setLimit} />{" "}
       
        <Pages page={page} setPage={setPage} limit={limit} />{" "}
        
      </section>
    </body>
  );
}

export default App;
